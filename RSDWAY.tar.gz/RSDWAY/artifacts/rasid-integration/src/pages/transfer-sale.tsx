import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  useTransferProducts, 
  useTransferCancelProducts, 
  useTransferBatchProducts,
  useTransferCancelBatchProducts,
  usePharmacySale, 
  usePharmacySaleCancel,
  SoapResponse
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Repeat, ShoppingCart, Ban, Layers, Lock, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { SoapResponseViewer } from "@/components/soap-response-viewer";
import { ProductListInput } from "@/components/product-list-input";
import { GlnInput } from "@/components/gln-input";
import { InvoiceBar } from "@/components/invoice-bar";
import { useInvoiceGuard } from "@/lib/use-invoice-guard";
import { useLanguage } from "@/lib/use-language";

function withInvoice<T extends object>(data: T, inv: string): T {
  if (!inv.trim()) return data;
  return { ...data, invoiceNumber: inv.trim() } as T;
}

type SnProduct   = { GTIN?: string; SN?: string;  BN?: string; XD?: string; QUANTITY?: number };
type BatchProduct = { GTIN?: string; BN?: string; XD?: string; QUANTITY?: number };

function exportSnFormToExcel(opName: string, glnHeader: string, glnValue: string, products: SnProduct[]) {
  const rows = products.length > 0
    ? products.map(p => ({ [glnHeader]: glnValue, GTIN: p.GTIN ?? "", SN: p.SN ?? "", BN: p.BN ?? "", XD: p.XD ?? "", QUANTITY: p.QUANTITY ?? "" }))
    : [{ [glnHeader]: glnValue, GTIN: "", SN: "", BN: "", XD: "", QUANTITY: "" }];
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opName.slice(0, 31));
  XLSX.writeFile(wb, `${opName}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

function exportBatchFormToExcel(opName: string, glnHeader: string, glnValue: string, products: BatchProduct[]) {
  const rows = products.length > 0
    ? products.map(p => ({ [glnHeader]: glnValue, GTIN: p.GTIN ?? "", BN: p.BN ?? "", XD: p.XD ?? "", QUANTITY: p.QUANTITY ?? "" }))
    : [{ [glnHeader]: glnValue, GTIN: "", BN: "", XD: "", QUANTITY: "" }];
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opName.slice(0, 31));
  XLSX.writeFile(wb, `${opName}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

function exportSaleFormToExcel(opName: string, extras: Record<string, string>, products: SnProduct[]) {
  const rows = products.length > 0
    ? products.map(p => ({ ...extras, GTIN: p.GTIN ?? "", SN: p.SN ?? "", BN: p.BN ?? "", XD: p.XD ?? "", QUANTITY: p.QUANTITY ?? "" }))
    : [{ ...extras, GTIN: "", SN: "", BN: "", XD: "", QUANTITY: "" }];
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opName.slice(0, 31));
  XLSX.writeFile(wb, `${opName}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

const transferSchema = z.object({
  toGLN: z.string().min(1, "رقم GLN المستلم مطلوب"),
  products: z.array(z.object({
    GTIN: z.string().min(1, "GTIN مطلوب"),
    SN: z.string().optional(),
    BN: z.string().optional(),
    XD: z.string().optional(),
    QUANTITY: z.coerce.number().optional()
  })).min(1, "يجب إضافة منتج واحد على الأقل")
});

const transferBatchSchema = z.object({
  toGLN: z.string().min(1, "رقم GLN المستلم مطلوب"),
  products: z.array(z.object({
    GTIN: z.string().min(1, "GTIN مطلوب"),
    BN: z.string().optional(),
    XD: z.string().optional(),
    QUANTITY: z.coerce.number().min(1, "الكمية مطلوبة")
  })).min(1, "يجب إضافة منتج واحد على الأقل")
});

const pharmacySaleSchema = z.object({
  toGLN: z.string().min(1, "رقم GLN للفرع مطلوب"),
  doctorId: z.string().optional(),
  patientNationalId: z.string().optional(),
  prescriptionId: z.string().min(1, "رقم الوصفة مطلوب"),
  prescriptionDate: z.string().min(1, "تاريخ الوصفة مطلوب"),
  products: z.array(z.object({
    GTIN: z.string().min(1, "GTIN مطلوب"),
    SN: z.string().optional(),
    BN: z.string().optional(),
    XD: z.string().optional(),
    QUANTITY: z.coerce.number().optional()
  })).min(1, "يجب إضافة منتج واحد على الأقل")
});

const pharmacySaleCancelSchema = z.object({
  toGLN: z.string().min(1, "رقم GLN للفرع مطلوب"),
  prescriptionId: z.string().min(1, "رقم الوصفة مطلوب"),
  products: z.array(z.object({
    GTIN: z.string().min(1, "GTIN مطلوب"),
    SN: z.string().optional(),
    BN: z.string().optional(),
    XD: z.string().optional(),
    QUANTITY: z.coerce.number().optional()
  })).min(1, "يجب إضافة منتج واحد على الأقل")
});

export default function TransferSalePage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const canDo = (op: string) => user?.role === "admin" || (user?.permissions ?? []).includes(op);
  const [response, setResponse] = useState<SoapResponse | null>(null);
  const [invoiceNum, setInvoiceNum] = useState("");
  const [invoiceAlert, setInvoiceAlert] = useState(true);
  const { guard, dialogOpen, confirmSubmit, cancelSubmit } = useInvoiceGuard(invoiceNum, invoiceAlert);

  const transferMutation = useTransferProducts();
  const transferCancelMutation = useTransferCancelProducts();
  const transferBatchMutation = useTransferBatchProducts();
  const transferCancelBatchMutation = useTransferCancelBatchProducts();
  const pharmacySaleMutation = usePharmacySale();
  const pharmacySaleCancelMutation = usePharmacySaleCancel();

  const transferForm = useForm<z.infer<typeof transferSchema>>({
    resolver: zodResolver(transferSchema),
    defaultValues: { toGLN: "", products: [] }
  });

  const transferBatchForm = useForm<z.infer<typeof transferBatchSchema>>({
    resolver: zodResolver(transferBatchSchema),
    defaultValues: { toGLN: "", products: [] }
  });

  const pharmacySaleForm = useForm<z.infer<typeof pharmacySaleSchema>>({
    resolver: zodResolver(pharmacySaleSchema),
    defaultValues: { toGLN: "", doctorId: "", patientNationalId: "", prescriptionId: "", prescriptionDate: "", products: [] }
  });

  const pharmacySaleCancelForm = useForm<z.infer<typeof pharmacySaleCancelSchema>>({
    resolver: zodResolver(pharmacySaleCancelSchema),
    defaultValues: { toGLN: "", prescriptionId: "", products: [] }
  });

  const onSuccess = (res: SoapResponse, msg: string) => {
    setResponse(res);
    toast({ title: t("common.saved"), description: msg });
  };
  const onError = () => toast({ title: t("common.error"), description: "حدث خطأ أثناء الاتصال بالنظام", variant: "destructive" });

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">{t("transfer.title")}</h1>
        <p className="text-muted-foreground mt-1">{t("transfer.subtitle")}</p>
      </div>

      <InvoiceBar
        value={invoiceNum}
        onChange={setInvoiceNum}
        alertEnabled={invoiceAlert}
        onAlertChange={setInvoiceAlert}
        dialogOpen={dialogOpen}
        onDialogConfirm={confirmSubmit}
        onDialogCancel={cancelSubmit}
      />

      <Tabs defaultValue={["transfer","transfer-batch","transfer-cancel","transfer-cancel-batch","pharmacy-sale","pharmacy-sale-cancel"].find(tab => canDo(`op:${tab}`))?.replace("pharmacy-sale-cancel","sale-cancel").replace("pharmacy-sale","sale") ?? "transfer"} onValueChange={() => setInvoiceNum("")} className="space-y-6">
        <TabsList className="flex flex-wrap h-auto gap-1">
          {canDo("op:transfer") && <TabsTrigger value="transfer">{t("transfer.tabTransfer")}</TabsTrigger>}
          {canDo("op:transfer-batch") && <TabsTrigger value="transfer-batch">{t("transfer.tabTransferBatch")}</TabsTrigger>}
          {canDo("op:transfer-cancel") && <TabsTrigger value="transfer-cancel">{t("transfer.tabTransferCancel")}</TabsTrigger>}
          {canDo("op:transfer-cancel-batch") && <TabsTrigger value="transfer-cancel-batch">{t("transfer.tabTransferCancelBatch")}</TabsTrigger>}
          {canDo("op:pharmacy-sale") && <TabsTrigger value="sale">{t("transfer.tabSale")}</TabsTrigger>}
          {canDo("op:pharmacy-sale-cancel") && <TabsTrigger value="sale-cancel">{t("transfer.tabSaleCancel")}</TabsTrigger>}
        </TabsList>

        {/* ── Transfer SN ── */}
        {canDo("op:transfer") && (
        <TabsContent value="transfer">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Repeat className="h-5 w-5 text-primary" />
                <CardTitle>{t("transfer.tabTransfer")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descTransfer")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...transferForm}>
                <form onSubmit={transferForm.handleSubmit((v) => guard(() => transferMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successTransfer")), onError })))} className="space-y-6">
                  <FormField control={transferForm.control} name="toGLN" render={({ field }) => (
                    <FormItem>
                      <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.toGLN")} />
                      <FormMessage />
                    </FormItem>
                  )} />
                  <ProductListInput mode="sn" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" disabled={transferMutation.isPending || !canDo("op:transfer")} title={!canDo("op:transfer") ? t("common.noPermission") : undefined}>
                      {transferMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:transfer") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeTransfer")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => exportSnFormToExcel("نقل-SN", "GLN المستلم", transferForm.getValues("toGLN"), transferForm.getValues("products") as SnProduct[])}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {/* ── Transfer Batch ── */}
        {canDo("op:transfer-batch") && (
        <TabsContent value="transfer-batch">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Layers className="h-5 w-5 text-primary" />
                <CardTitle>{t("transfer.tabTransferBatch")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descTransferBatch")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...transferBatchForm}>
                <form onSubmit={transferBatchForm.handleSubmit((v) => guard(() => transferBatchMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successTransferBatch")), onError })))} className="space-y-6">
                  <FormField control={transferBatchForm.control} name="toGLN" render={({ field }) => (
                    <FormItem>
                      <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.toGLN")} />
                      <FormMessage />
                    </FormItem>
                  )} />
                  <ProductListInput name="products" mode="batch" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" disabled={transferBatchMutation.isPending || !canDo("op:transfer-batch")} title={!canDo("op:transfer-batch") ? t("common.noPermission") : undefined}>
                      {transferBatchMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:transfer-batch") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeTransferBatch")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => exportBatchFormToExcel("نقل-Batch", "GLN المستلم", transferBatchForm.getValues("toGLN"), transferBatchForm.getValues("products") as BatchProduct[])}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {/* ── Transfer Cancel SN ── */}
        {canDo("op:transfer-cancel") && (
        <TabsContent value="transfer-cancel">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Ban className="h-5 w-5 text-destructive" />
                <CardTitle>{t("transfer.tabTransferCancel")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descTransferCancel")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...transferForm}>
                <form onSubmit={transferForm.handleSubmit((v) => guard(() => transferCancelMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successTransferCancel")), onError })))} className="space-y-6">
                  <FormField control={transferForm.control} name="toGLN" render={({ field }) => (
                    <FormItem>
                      <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.toGLN")} />
                      <FormMessage />
                    </FormItem>
                  )} />
                  <ProductListInput mode="sn" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" variant="destructive" disabled={transferCancelMutation.isPending || !canDo("op:transfer-cancel")} title={!canDo("op:transfer-cancel") ? t("common.noPermission") : undefined}>
                      {transferCancelMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:transfer-cancel") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeTransferCancel")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => exportSnFormToExcel("إلغاء-نقل-SN", "GLN المستلم", transferForm.getValues("toGLN"), transferForm.getValues("products") as SnProduct[])}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {/* ── Transfer Cancel Batch ── */}
        {canDo("op:transfer-cancel-batch") && (
        <TabsContent value="transfer-cancel-batch">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Ban className="h-5 w-5 text-destructive" />
                <CardTitle>{t("transfer.tabTransferCancelBatch")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descTransferCancelBatch")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...transferBatchForm}>
                <form onSubmit={transferBatchForm.handleSubmit((v) => guard(() => transferCancelBatchMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successTransferCancelBatch")), onError })))} className="space-y-6">
                  <FormField control={transferBatchForm.control} name="toGLN" render={({ field }) => (
                    <FormItem>
                      <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.toGLN")} />
                      <FormMessage />
                    </FormItem>
                  )} />
                  <ProductListInput name="products" mode="batch" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" variant="destructive" disabled={transferCancelBatchMutation.isPending || !canDo("op:transfer-cancel-batch")} title={!canDo("op:transfer-cancel-batch") ? t("common.noPermission") : undefined}>
                      {transferCancelBatchMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:transfer-cancel-batch") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeTransferCancelBatch")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => exportBatchFormToExcel("إلغاء-نقل-Batch", "GLN المستلم", transferBatchForm.getValues("toGLN"), transferBatchForm.getValues("products") as BatchProduct[])}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {/* ── Pharmacy Sale ── */}
        {canDo("op:pharmacy-sale") && (
        <TabsContent value="sale">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-primary" />
                <CardTitle>{t("transfer.cardSale")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descSale")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...pharmacySaleForm}>
                <form onSubmit={pharmacySaleForm.handleSubmit((v) => guard(() => pharmacySaleMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successSale")), onError })))} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <FormField control={pharmacySaleForm.control} name="toGLN" render={({ field }) => (
                      <FormItem>
                        <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.branchGLN")} />
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={pharmacySaleForm.control} name="prescriptionId" render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("transfer.prescriptionId")}</FormLabel>
                        <FormControl><Input dir="ltr" className="text-left" placeholder={t("transfer.prescriptionIdPlaceholder")} {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={pharmacySaleForm.control} name="prescriptionDate" render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("transfer.prescriptionDate")}</FormLabel>
                        <FormControl><Input dir="ltr" className="text-left" type="date" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={pharmacySaleForm.control} name="doctorId" render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("transfer.doctorId")}</FormLabel>
                        <FormControl><Input dir="ltr" className="text-left" placeholder="Doctor ID" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={pharmacySaleForm.control} name="patientNationalId" render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("transfer.patientNationalId")}</FormLabel>
                        <FormControl><Input dir="ltr" className="text-left" placeholder="National ID" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <ProductListInput mode="sn" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" disabled={pharmacySaleMutation.isPending || !canDo("op:pharmacy-sale")} title={!canDo("op:pharmacy-sale") ? t("common.noPermission") : undefined}>
                      {pharmacySaleMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:pharmacy-sale") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeSale")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => {
                        const v = pharmacySaleForm.getValues();
                        exportSaleFormToExcel("بيع-صيدلية", { "GLN الفرع": v.toGLN, "رقم الوصفة": v.prescriptionId, "تاريخ الوصفة": v.prescriptionDate, "رقم الطبيب": v.doctorId ?? "", "الهوية الوطنية": v.patientNationalId ?? "" }, v.products as SnProduct[]);
                      }}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {/* ── Pharmacy Sale Cancel ── */}
        {canDo("op:pharmacy-sale-cancel") && (
        <TabsContent value="sale-cancel">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Ban className="h-5 w-5 text-destructive" />
                <CardTitle>{t("transfer.cardSaleCancel")}</CardTitle>
              </div>
              <CardDescription>{t("transfer.descSaleCancel")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...pharmacySaleCancelForm}>
                <form onSubmit={pharmacySaleCancelForm.handleSubmit((v) => guard(() => pharmacySaleCancelMutation.mutate({ data: withInvoice(v, invoiceNum) }, { onSuccess: (r) => onSuccess(r, t("transfer.successSaleCancel")), onError })))} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField control={pharmacySaleCancelForm.control} name="toGLN" render={({ field }) => (
                      <FormItem>
                        <GlnInput value={field.value} onChange={field.onChange} label={t("transfer.branchGLN")} />
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={pharmacySaleCancelForm.control} name="prescriptionId" render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("transfer.prescriptionId")}</FormLabel>
                        <FormControl><Input dir="ltr" className="text-left" placeholder={t("transfer.prescriptionIdPlaceholder")} {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <ProductListInput mode="sn" />
                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" variant="destructive" disabled={pharmacySaleCancelMutation.isPending || !canDo("op:pharmacy-sale-cancel")} title={!canDo("op:pharmacy-sale-cancel") ? t("common.noPermission") : undefined}>
                      {pharmacySaleCancelMutation.isPending ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : !canDo("op:pharmacy-sale-cancel") ? <Lock className="me-2 h-4 w-4" /> : null}
                      {t("transfer.executeSaleCancel")}
                    </Button>
                    <Button type="button" variant="outline"
                      onClick={() => {
                        const v = pharmacySaleCancelForm.getValues();
                        exportSaleFormToExcel("إلغاء-بيع-صيدلية", { "GLN الفرع": v.toGLN, "رقم الوصفة": v.prescriptionId }, v.products as SnProduct[]);
                      }}>
                      <Download className="me-2 h-4 w-4" />{t("dispatch.downloadData")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        )}
      </Tabs>

      <SoapResponseViewer response={response} />
    </div>
  );
}
